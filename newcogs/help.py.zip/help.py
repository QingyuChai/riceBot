import discord
import datetime

from discord.ext import commands



def pagify(text, delims=["\n"], *, escape=True, shorten_by=8,
           page_length=2000):
    """DOES NOT RESPECT MARKDOWN BOXES OR INLINE CODE"""
    in_text = text
    if escape:
        num_mentions = text.count("@here") + text.count("@everyone")
        shorten_by += num_mentions
    page_length -= shorten_by
    while len(in_text) > page_length:
        closest_delim = max([in_text.rfind(d, 0, page_length)
                             for d in delims])
        closest_delim = closest_delim if closest_delim != -1 else page_length
        if escape:
            to_send = escape_mass_mentions(in_text[:closest_delim])
        else:
            to_send = in_text[:closest_delim]
        yield to_send
        in_text = in_text[closest_delim:]

    if escape:
        yield escape_mass_mentions(in_text)
    else:
        yield in_text

class Help:
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='help', pass_context=True)
    async def _help(self, ctx):

        msg = "***Command list:***"
        color = 0x032449

        em=discord.Embed(description=msg, color=color)

        await self.bot.say("Hello.")
        #await self.bot.say(coms)
        final_coms = {}
        com_groups = []
        for com in self.bot.commands:
            try:
                if self.bot.commands[com].module.__name__ not in com_groups:
                    com_groups.append(self.bot.commands[com].module.__name__)
                else:
                    continue
            except Exception as e:
                print(e)
                print(datetime.datetime.now())
                continue
        print(com_groups)
        for com_group in com_groups:
            commands = []
            for com in self.bot.commands:
                if com_group == self.bot.commands[com].module.__name__:
                    #print("PLS WURK")
                    commands.append(com)
            final_coms[com_group] = commands

            #print(commands)
        #print(final_coms)
        count = 0
        for group in final_coms:
            #width = len(max(words, key=len))
            if count == 2:
                em=discord.Embed(description=msg, color=color)

            msg = ""
            for com in final_coms[group]:
                drugs = self.bot.commands[com].help
                if not drugs:
                    drugs = "No description available."
                #msg += '```md\n'
                msg += '**{}**\n'.format(com)
                #msg += '```'
                msg += '    {}\n'.format(str(drugs))
            cog_name = group.replace("cogs.", "").title()
            cog =  "```markdown\n"
            cog += cog_name
            cog += "\n```"
            em.add_field(name=cog, value=msg, inline=False)
            if count == 2:
                await self.bot.say(embed=em)
                count = 0
            else:
                count += 1

        if count != 3:
            await self.bot.say(embed=em)


def setup(bot):
    bot.remove_command('help')
    bot.add_cog(Help(bot))
